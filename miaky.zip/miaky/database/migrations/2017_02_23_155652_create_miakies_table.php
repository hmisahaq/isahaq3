<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMiakiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('miakies', function(Blueprint $table) {
            $table->increments('id');
            $table->string('title');
            $table->string('category');
            $table->string('partner');
            $table->text('Description');
            $table->string('Publish');
            $table->string('price');
            $table->string('Feature');
            $table->string('Discount');
            $table->string('File');
            $table->string('Thambnail');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('miakies');
    }
}
