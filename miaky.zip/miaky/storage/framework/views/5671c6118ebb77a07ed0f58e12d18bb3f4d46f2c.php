<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/font-awesome.css'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
         

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Miaky</div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/admin/miaky/create')); ?>" class="btn btn-success btn-sm" title="Add New Miaky">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>

                        <?php echo Form::open(['method' => 'GET', 'url' => '/admin/miaky', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <?php echo Form::close(); ?>


                        <br/>
                        <br/>
						<?php echo e($i=1); ?>

                        <div class="table-responsive">
                            <table class="table table-bordered table-responsive">
                                <thead>
                                    <tr>
                                        <th>#</th><th>Title</th><th>Category</th><th>Partner</th><th>Publish</th><th>Price</th><th>Feature</th><th>Discount</th><th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $miaky; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($item->title); ?></td><td><?php echo e($item->category); ?></td><td><?php echo e($item->partner); ?></td>
										<td><?php echo e($item->Publish); ?></td><td><?php echo e($item->price); ?></td><td><?php echo e($item->Feature); ?></td><td><?php echo e($item->Discount); ?>%</td>
                                        <td>
                                            <a href="<?php echo e(url('/admin/miaky/' . $item->id)); ?>" title="View Miaky"><button class="btn btn-info btn-xs"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="<?php echo e(url('/admin/miaky/' . $item->id . '/edit')); ?>" title="Edit Miaky"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
                                            <?php echo Form::open([
                                                'method'=>'DELETE',
                                                'url' => ['/admin/miaky', $item->id],
                                                'style' => 'display:inline'
                                            ]); ?>

                                                <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-xs',
                                                        'title' => 'Delete Miaky',
                                                        'onclick'=>'return confirm("Confirm delete?")'
                                                )); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination-wrapper"> <?php echo $miaky->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>