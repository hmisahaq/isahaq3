<?php echo Html::style('/css/bootstrap.min.css'); ?>


<?php echo Html::script('/js/bootstrap.min.js'); ?> 
 <table>
<tr>
<td>
<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title', 'Title', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('title', null, ['class' => 'form-control','placeholder'=>'Product Title']); ?>

        <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('category') ? 'has-error' : ''); ?>">
    <?php echo Form::label('category', 'Category', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('category', array('Video'=>'Video','Audio'=>'Audio','Image'=>'Image'), null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('category', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('partner') ? 'has-error' : ''); ?>">
    <?php echo Form::label('partner', 'Partner', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('partner', array('Spondon'=>'Spondon','SSl'=>'SSl'), null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('partner', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('Description') ? 'has-error' : ''); ?>">
    <?php echo Form::label('Description', 'Description', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('Description', null, ['class' => 'form-control','placeholder'=>'Product Descriptions','style'=>'height:150px; width:215px']); ?>

        <?php echo $errors->first('Description', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
</td>
<td>
<div class="form-group <?php echo e($errors->has('Publish') ? 'has-error' : ''); ?>">
    <?php echo Form::label('Publish', 'Publish', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::radio('Publish', 'Yes', ['class' => 'form-control']); ?>Yes
		<?php echo Form::radio('Publish', 'No', ['class' => 'form-control']); ?>No
        <?php echo $errors->first('Publish', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
    <?php echo Form::label('price', 'Price', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('price', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('File') ? 'has-error' : ''); ?>">
    <?php echo Form::label('File', 'File', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::file('File', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('File', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('Thambnail') ? 'has-error' : ''); ?>">
    <?php echo Form::label('Thambnail', 'Thambnail', ['class' => 'col-md-4 control-label']); ?>

	
    <div class="col-md-6">
        <?php echo Form::file('Thambnail', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('Thambnail', '<p class="help-block">:message</p>'); ?>

    </div>
</div>



<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

  
	</div>
</div>
</td>
<td><div class="form-group <?php echo e($errors->has('Feature') ? 'has-error' : ''); ?>">
    <?php echo Form::label('Feature', 'Feature', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::radio('Feature','Yes', ['class' => 'form-control']); ?>Yes
        <?php echo Form::radio('Feature','NO', ['class' => 'form-control']); ?>No
		
        <?php echo $errors->first('Feature', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('Discount') ? 'has-error' : ''); ?>">
    <?php echo Form::label('Discount', 'Discount', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('Discount', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('Discount', '<p class="help-block">:message</p>%'); ?>

    </div>
</div>

<img src="images/camera.jpg"  style="height:100px; width:100px" alt="images/camera.jpg">

</td>
<tr>
</table>